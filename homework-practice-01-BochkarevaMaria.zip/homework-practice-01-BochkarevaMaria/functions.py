def prod_non_zero_diag(X):
    product = 1
    for i in range(min(len(X), len(X[0]))):
        if (X[i][i] != 0):
            product *= X[i][i]
    return product


def are_multisets_equal(x, y):
    x.sort()
    y.sort()
    return (x == y)


def max_after_zero(x):
    f = 0
    for i in range(len(x) - 1):
        if (x[i] == 0):
            if (f == 0):
                max = x[i + 1]
                f = 1
            elif (max < x[i + 1]):
                max = x[i + 1]
    return max


def convert_image(X, y):
    result = list()
    n = len(X[0])
    m = len(X)
    l = len(y)
    for i in range(m):
        result.append(list())
        for j in range(n):
            sum = 0.
            for k in range(l):
                sum += X[i][j][k] * y[k]
            result[i].append(sum)
    return result


def run_length_encoding(x):
    result = list()
    result.append(list())
    result.append(list())
    current = x[0]
    count = 1
    for i in range(1, len(x)):
        if (x[i] == current):
            count += 1
        else:
            result[0].append(current)
            result[1].append(count)
            current = x[i]
            count = 1
    result[0].append(current)
    result[1].append(count)
    return result


def pairwise_distance(X, Y):
    result = list()
    for i in range(len(X)):
        result.append(list())
        for j in range(len(Y)):
            sum = 0
            for k in range(len(Y[j])):
                sum += (X[i][k] - Y[j][k])**2
            result[i].append(sum**(1/2))
    return result
