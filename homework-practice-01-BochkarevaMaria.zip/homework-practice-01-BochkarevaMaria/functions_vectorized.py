import numpy as np


def prod_non_zero_diag(X):
    Y = np.diag(X)
    result = Y[Y != 0].prod()
    return result


def are_multisets_equal(x, y):
    if (len(x) != len(y)):
        return False
    x = np.sort(x)
    y = np.sort(y)
    return (x.__eq__(y).min() == 1)


def max_after_zero(X):
    Y1 = X[1:]
    Y2 = X[0:-1]
    return Y1[Y2 == 0].max()


def convert_image(X, y):
    X = X * y
    return X.sum(axis=2)


def run_length_encoding(x):
    y = np.diff(x)
    y = np.hstack((y, [1]))
    ind = np.where(y != 0)
    result = np.hstack(([-1], ind[0]))
    return (x[ind], np.diff(result))


def pairwise_distance(X, Y):
    A = np.matrix((X * X).sum(axis=1)).T
    B = X.dot(Y.T)
    C = np.matrix((Y * Y).sum(axis=1))
    return np.sqrt(A - 2 * B + C)
